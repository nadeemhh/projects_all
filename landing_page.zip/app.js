const express = require('express')
const path = require('path')
const app = express()
app.use(express.json())
const mongoose = require('mongoose')
let cors = require('cors')
app.use(cors())
var nodemailer = require('nodemailer');
const publicDirectoryPath = path.join(__dirname, './client')
app.use(express.static(publicDirectoryPath))
const port = process.env.PORT || 3600

mongoose.connect('mongodb+srv://eshop-user:1234567Ww@cluster0.m7qgjqu.mongodb.net/?retryWrites=true&w=majority')

const Emails = mongoose.model('Emails', {
      name : {
            type: String
               
            },

      email : {
        type: String
           
        }
       
    })



//form_data

app.post('/formdata', async (req, res) => {

      console.log('req.body.scriptname',req.body)

      var transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
              user: 'dummy@gmail.com',
              pass: 'gnhgvjgjg'
            }
          });
          
          var mailOptions = {
            from: 'dummy@gmail.com',
            to: req.body.email,
            subject: 'your free audiobook',
            html: `<a href="https://finance.yahoo.com/quote/aapl/?guccounter=1" target="_blank">click on this link</a>`
          };
          
        
        transporter.sendMail(mailOptions, function(error, info){
        if (error) {
        console.log(error);
        } else {
        console.log('Email sent: ' + info.response);
        }
        });
      

            const mails = new Emails({
      name:req.body.name,
      email:req.body.email
   
        })
   mails.save() 
   res.send('done')

         })


         app.get('/getemails', async (req, res) => {
            let emails = await Emails.find({}).exec();   
            console.log(emails)
           res.send(emails)

               })

app.listen(port)

